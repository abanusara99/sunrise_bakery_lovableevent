<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- The bakery's single-page content lives in the index route with in-page navigation; keep the first screen directly accessible at /.
- Define bakery styling and color roles in src/styles.css and use the shared Button for calls to action, so the visual system stays consistent.
- Import bakery photography from src/assets to keep the displayed images bundled with the website.
- Prebundle Radix Slot at startup alongside the template's React dependencies to prevent late dependency discovery from mixing React chunks in an open preview.
- Use BakeryHeader on the home and pickup pages so mobile navigation behavior stays consistent.
- Validate feedback with the shared schema and submit through a public server function with insert-only visitor access, keeping submissions private.
