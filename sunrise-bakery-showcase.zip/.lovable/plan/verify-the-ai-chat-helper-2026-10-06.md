# Verify the AI chat helper

The Sunrise Bakery chat helper is already built: a round orange question-mark button in the bottom corner that opens a chat panel. It answers only from the bakery's services, prices, hours, address, and phone, and saves booking/order requests (name + phone) to the database.

## What to do

1. Open the site in the browser and open the chat helper.
2. Ask "What time do you close?" — expect a short, friendly answer with the 7 PM closing time (Tue–Sun, closed Monday).
3. Ask "I want to book for Saturday." — expect the helper to ask for a name and phone number.
4. Give a test name and phone, confirm the helper saves it, and check the database for the new request row.
5. Ask something it cannot know — confirm it replies "Please call us at +1 000-000-0000."

## If anything fails

- Fix the chat answers or saving in the existing chat code, then re-run the same tests.

## Technical details

- Chat UI: `src/components/ChatHelper.tsx` (mounted in `src/routes/__root.tsx`).
- Chat brain: `src/lib/chat.server.ts` via `src/routes/api/chat.ts`, using Lovable AI.
- Saved requests go to the `chat_requests` table in the database.
