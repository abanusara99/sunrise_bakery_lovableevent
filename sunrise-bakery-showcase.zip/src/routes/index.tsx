import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { ArrowDown, ArrowUpRight, CakeSlice, Check, Croissant, Globe, Heart, MapPin, Phone, Sun, UtensilsCrossed } from "lucide-react";
import { Button } from "@/components/ui/button";
import breadImage from "@/assets/bakery-bread.jpg";
import cakeImage from "@/assets/bakery-cake.jpg";
import pastriesImage from "@/assets/bakery-pastries.jpg";
import cateringImage from "@/assets/bakery-catering.jpg";
import { defaultQuoteServiceId, estimateQuote, money, quoteServices } from "@/lib/quote-pricing";
import { submitQuote } from "@/lib/quotes.functions";
import { BakeryHeader } from "@/components/BakeryHeader";
import { FeedbackForm } from "@/components/FeedbackForm";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "Sunrise Bakery | Freshly Baked in Astoria, Queens" },
    { name: "description", content: "Your family bakery in Astoria, Queens. Fresh bread and pastries every morning, custom birthday cakes, and catering trays. Mon–Fri, 8 AM–9 PM. Closed weekends." },
    { property: "og:title", content: "Sunrise Bakery | Your Neighborhood Bakery" },
    { property: "og:description", content: "Fresh bread and pastries baked every morning in Astoria, Queens. Visit Monday through Friday, 8 AM to 9 PM." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: Index,
});

const services = [
  { icon: CakeSlice, name: "Custom birthday cakes", description: "A little sweetness for your big day. Made with care, for moments worth celebrating." },
  { icon: Croissant, name: "Fresh bread and pastries", description: "Golden crusts, buttery layers, and that just-baked feeling. A fresh start to every morning." },
  { icon: UtensilsCrossed, name: "Catering trays for events", description: "Something delicious to share. Bring a taste of our family bakery to your next gathering." },
];

const photos = [
  { src: breadImage, alt: "Fresh sourdough loaves, bread rolls, and golden croissants on a bakery table", caption: "This morning’s loaves and croissants", wide: true },
  { src: cakeImage, alt: "Custom birthday cake with cream frosting, warm orange berries and edible flowers", caption: "Custom birthday cakes", wide: false },
  { src: pastriesImage, alt: "Basket of golden croissants and buttery pastries on a cream counter", caption: "Buttery morning pastries", wide: false },
  { src: cateringImage, alt: "Catering trays of golden fried buns, some dusted with powdered sugar and some glazed with honey, set out for an event", caption: "Fried buns for events", wide: false },
];

function QuoteCard() {
  const sendQuote = useServerFn(submitQuote);
  const [serviceId, setServiceId] = useState(defaultQuoteServiceId);
  const [quantity, setQuantity] = useState("2");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [status, setStatus] = useState<"idle" | "saving" | "sent" | "error">("idle");
  const [note, setNote] = useState("");

  const quantityNumber = Number.parseInt(quantity, 10);
  const estimate = estimateQuote(serviceId, Number.isFinite(quantityNumber) ? quantityNumber : 0);
  const chosen = estimate?.service;

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!estimate) {
      setStatus("error");
      setNote("Please choose a service and enter a quantity between 1 and 999.");
      return;
    }
    setStatus("saving");
    setNote("");
    try {
      const result = await sendQuote({
        data: { serviceId, quantity: estimate.quantity, name: name.trim(), phone: phone.trim() },
      });
      setStatus("sent");
      setNote(`Thanks, ${name.trim().split(" ")[0] || "friend"}! Your quote for ${result.quantity} ${result.serviceName.toLowerCase()} (about ${money(result.total)}) is with us. We’ll call you to confirm the details.`);
    } catch (error) {
      setStatus("error");
      setNote(error instanceof Error && error.message ? error.message : "We couldn’t save your quote just now. Please give us a call instead.");
    }
  };

  return (
    <div className="quote-card">
      <div className="quote-intro">
        <p className="eyebrow">NO PRESSURE, JUST A STARTING NUMBER</p>
        <h2>Get a quick quote.</h2>
        <p>Tell us what you’re baking up. Pick a service, add your size or quantity, and see an estimated price right away. Send it over and we’ll confirm the details by phone.</p>
      </div>
      <form className="quote-form" onSubmit={handleSubmit}>
        <fieldset className="quote-services">
          <legend>Choose a service</legend>
          {quoteServices.map((service) => (
            <label key={service.id} className={serviceId === service.id ? "quote-service chosen" : "quote-service"}>
              <input
                type="radio"
                name="quote-service"
                value={service.id}
                checked={serviceId === service.id}
                onChange={() => {
                  setServiceId(service.id);
                  setStatus("idle");
                  setNote("");
                }}
              />
              <span className="quote-service-name">{service.name}</span>
              <span className="quote-service-price">{money(service.unitPrice)} <small>per {service.unitLabel}</small></span>
            </label>
          ))}
        </fieldset>

        <div className="quote-fields">
          <label className="quote-field">
            <span>{chosen ? chosen.quantityLabel : "Size or quantity"}</span>
            <input
              type="number"
              min={1}
              max={999}
              step={1}
              inputMode="numeric"
              value={quantity}
              onChange={(event) => {
                setQuantity(event.target.value);
                setStatus("idle");
                setNote("");
              }}
              placeholder={quoteServices.find((service) => service.id === service.id)?.placeholder ?? "e.g. 2"}
              required
            />
          </label>
          <label className="quote-field">
            <span>Your name</span>
            <input type="text" maxLength={120} value={name} onChange={(event) => setName(event.target.value)} placeholder="First name is fine" required />
          </label>
          <label className="quote-field">
            <span>Phone</span>
            <input type="tel" maxLength={30} value={phone} onChange={(event) => setPhone(event.target.value)} placeholder="Your phone number" required />
          </label>
        </div>

        <div className="quote-total">
          <div>
            <span className="quote-total-label">Estimated price</span>
            <p className="quote-total-value">{estimate ? money(estimate.total) : "—"}</p>
            <p className="quote-total-math">
              {estimate
                ? `${money(estimate.unitPrice)} × ${estimate.quantity} ${estimate.service.unitLabel}${estimate.quantity === 1 ? "" : "s"}`
                : "Pick a service and enter a quantity to see the estimate."}
            </p>
          </div>
          <Button type="submit" size="lg" disabled={status === "saving"}>
            {status === "saving" ? "Sending…" : "Send me this quote"}
            {status === "saving" ? null : <ArrowUpRight />}
          </Button>
        </div>

        {note ? (
          <p className={status === "sent" ? "quote-note quote-note-ok" : "quote-note quote-note-bad"} role="status">
            {status === "sent" ? <Check size={17} aria-hidden="true" /> : null}
            {note}
          </p>
        ) : null}
        <p className="quote-fineprint">Estimates only — final pricing depends on flavors, decoration and delivery. We’ll never share your number.</p>
      </form>
    </div>
  );
}

function Index() {
  return (
    <div className="bakery-page">
      <BakeryHeader />
      <main>
        <section className="bakery-hero" id="home">
          <img className="hero-photo" src={breadImage} alt="Fresh sourdough loaves, bread rolls, and golden croissants on a bakery table" width={1536} height={1024} fetchPriority="high" />
          <div className="hero-shade" />
          <div className="hero-content">
            <p className="eyebrow"><span /> YOUR NEIGHBORHOOD BAKERY · ASTORIA, QUEENS</p>
            <h1>Fresh bread and pastries baked every morning</h1>
            <p className="hero-copy">From our family’s oven to your table.<br />A little warmth, a little sweetness, a whole lot of love.</p>
            <Button asChild variant="secondary" size="lg"><a href="#services">Discover our baking <ArrowDown /></a></Button>
          </div>
          <div className="hero-note"><Sun size={19} /><span>Good mornings start here.</span></div>
        </section>
        <section className="services-section" id="services">
          <div className="section-heading"><p className="eyebrow">BAKED WITH LOVE, SHARED WITH YOU</p><h2>A little something<br />for every occasion.</h2><p>Everyday favorites and special celebrations.<br />Always made with a personal touch.</p></div>
          <div className="services-grid">{services.map(({ icon: Icon, name, description }, index) => <article className="service" key={name}><div className="service-top"><Icon size={34} strokeWidth={1.3} /><span>0{index + 1}</span></div><h3>{name}</h3><p>{description}</p></article>)}</div>
          <div className="family-note"><Heart size={17} /><p>Family-owned. Neighborhood-loved. Proudly baking in Astoria, Queens.</p></div>
        </section>
        <section className="photo-section" id="photos">
          <div className="section-heading"><p className="eyebrow">A LITTLE PEEK INSIDE OUR OVEN</p><h2>From our bakery<br />to your table.</h2><p>A few snapshots of what comes<br />out of our ovens each morning.</p></div>
          <div className="photo-grid">{photos.map(({ src, alt, caption, wide }) => <figure className={`photo${wide ? " photo-wide" : ""}`} key={caption}><img src={src} alt={alt} width={1200} height={912} loading={wide ? "eager" : "lazy"} /><figcaption>{caption}</figcaption></figure>)}</div>
        </section>
        <section className="quote-section" id="quote">
          <QuoteCard />
        </section>
        <FeedbackForm />
        <section className="visit-section" id="visit">
          <div><p className="eyebrow">THERE’S A PLACE FOR YOU HERE</p><h2>Come on in.<br />We’ll save you a slice.</h2><p className="visit-copy">Stop by for your morning loaf, a sweet treat,<br />or just a friendly hello.</p></div>
          <div className="visit-details"><div className="hours"><h3>Opening hours</h3><div><span>Monday — Friday</span><strong>8 AM — 9 PM</strong></div><div className="closed"><span>Saturday — Sunday</span><span>Closed</span></div></div><div className="contact-details"><div><MapPin size={20} /><p><span>Astoria, Queens, NY</span></p></div><div><Phone size={19} /><p>+1 000-000-0000</p></div><div><Globe size={19} className="developed-by-icon" /><p><a className="developed-by" href="https://anuportfoliovisit.vercel.app/" target="_blank" rel="noopener noreferrer">Developed By</a></p></div></div></div>
        </section>
      </main>
      <footer className="site-footer"><div className="footer-inner"><a href="#home" className="wordmark footer-wordmark"><Sun aria-hidden="true" /><span>Sunrise<span className="wordmark-small">BAKERY</span></span></a><p>Made with love. Fresh every morning.</p><span>© 2026 Sunrise Bakery</span></div></footer>
    </div>
  );
}
