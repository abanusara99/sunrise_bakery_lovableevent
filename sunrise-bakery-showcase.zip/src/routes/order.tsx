import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Check, Minus, Plus, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { money } from "@/lib/quote-pricing";
import { orderLines, orderTotal, pickupMenu, type PickupQuantities } from "@/lib/pickup-menu";
import { submitPickupOrder } from "@/lib/orders.functions";
import { BakeryHeader } from "@/components/BakeryHeader";

export const Route = createFileRoute("/order")({
  head: () => ({ meta: [
    { title: "Order for Pickup | Sunrise Bakery, Astoria" },
    { name: "description", content: "Order cake slices, wedding cakes and party cakes from Sunrise Bakery for pickup in Astoria, Queens." },
    { property: "og:title", content: "Order for Pickup | Sunrise Bakery" },
    { property: "og:description", content: "Pick your treats, choose a pickup time, and we'll text you when it's ready." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: OrderPage,
});

function OrderPage() {
  const send = useServerFn(submitPickupOrder);
  const [qty, setQty] = useState<PickupQuantities>({});
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [pickupTime, setPickupTime] = useState("");
  const [status, setStatus] = useState<"idle" | "saving" | "sent" | "error">("idle");
  const [error, setError] = useState("");
  const lines = orderLines(qty);
  const total = orderTotal(qty);

  const change = (id: string, value: number) => setQty((q) => ({ ...q, [id]: Math.max(0, Math.min(999, value || 0)) }));

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (lines.length === 0) { setStatus("error"); setError("Please add at least one item."); return; }
    setStatus("saving");
    try {
      await send({ data: { quantities: qty, name, phone, pickupTime } });
      setStatus("sent");
    } catch (err) {
      setStatus("error");
      setError(err instanceof Error && err.message ? err.message : "We couldn't save your order. Please call us.");
    }
  }

  return (
    <div className="bakery-page">
      <BakeryHeader />
      <main className="order-main">
        <div className="section-heading"><p className="eyebrow">FRESH FROM OUR OVEN</p><h2>Order for pickup.</h2><p>Pick your treats and a time. We’ll have them<br />boxed and waiting for you.</p></div>
        {status === "sent" ? (
          <div className="order-card order-done" role="status"><Check size={36} /><h3>Order received! We will text you when it is ready.</h3><p>Total: {money(total)}</p><Button onClick={() => { setQty({}); setStatus("idle"); }}>Place another order</Button></div>
        ) : (
          <form className="order-card" onSubmit={onSubmit}>
            <ul className="order-menu">
              {pickupMenu.map((item) => (
                <li key={item.id} className="order-item">
                  <div><span className="order-item-name">{item.name}</span><span className="order-item-price">{money(item.price)} each</span></div>
                  <div className="order-stepper">
                    <button type="button" aria-label={`Remove one ${item.name}`} onClick={() => change(item.id, (qty[item.id] ?? 0) - 1)}><Minus size={16} /></button>
                    <input aria-label={`${item.name} quantity`} type="number" inputMode="numeric" min={0} max={999} value={qty[item.id] ?? 0} onChange={(e) => change(item.id, parseInt(e.target.value, 10))} />
                    <button type="button" aria-label={`Add one ${item.name}`} onClick={() => change(item.id, (qty[item.id] ?? 0) + 1)}><Plus size={16} /></button>
                  </div>
                </li>
              ))}
            </ul>
            <div className="order-summary">
              {lines.map((l) => <div key={l.id}><span>{l.quantity} × {l.name}</span><span>{money(l.lineTotal)}</span></div>)}
              <div className="order-total"><span>Total</span><strong data-testid="order-total">{money(total)}</strong></div>
            </div>
            <div className="quote-fields">
              <label className="quote-field"><span>Your name</span><input required value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" /></label>
              <label className="quote-field"><span>Phone</span><input required type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} autoComplete="tel" /></label>
              <label className="quote-field"><span>Pickup time</span><input required type="datetime-local" value={pickupTime} onChange={(e) => setPickupTime(e.target.value)} /></label>
            </div>
            <Button type="submit" size="lg" disabled={status === "saving"}>{status === "saving" ? "Sending…" : "Place pickup order"}</Button>
            {status === "error" && <p className="quote-note quote-note-bad" role="alert">{error}</p>}
            <p className="quote-fineprint">Pickup Mon–Fri, 8 AM – 9 PM. Pay when you pick up.</p>
          </form>
        )}
      </main>
      <footer className="site-footer"><div className="footer-inner"><Link to="/" className="wordmark footer-wordmark"><Sun aria-hidden="true" /><span>Sunrise<span className="wordmark-small">BAKERY</span></span></Link><p>Made with love. Fresh every morning.</p><span>© 2026 Sunrise Bakery</span></div></footer>
    </div>
  );
}
