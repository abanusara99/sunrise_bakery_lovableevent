import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { feedbackSchema, type FeedbackInput } from "./feedback-schema";

export const submitFeedback = createServerFn({ method: "POST" })
  .inputValidator((input: FeedbackInput) => feedbackSchema.parse(input))
  .handler(async ({ data }) => {
    const url = process.env["SUPABASE_URL"];
    const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
    if (!url || !key) throw new Error("Feedback is unavailable right now. Please call us.");
    const client = createClient(url, key, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: { fetch: (input, init) => {
        const headers = new Headers(init?.headers);
        if (key.startsWith("sb_") && headers.get("Authorization") === `Bearer ${key}`) headers.delete("Authorization");
        headers.set("apikey", key);
        return fetch(input, { ...init, headers });
      } },
    });
    const { error } = await client.from("bakery_feedback").insert({ customer_name: data.name, rating: data.rating, message: data.message });
    if (error) throw new Error("We couldn’t save your feedback. Please try again.");
    return { ok: true };
  });