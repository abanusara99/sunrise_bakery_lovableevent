import { createOpenAI } from "@ai-sdk/openai";
import { createClient } from "@supabase/supabase-js";
import { convertToModelMessages, stepCountIs, streamText, tool, type UIMessage } from "ai";
import { z } from "zod";

import { quoteServices } from "./quote-pricing";
import { pickupMenu } from "./pickup-menu";

const PHONE = "+1 000-000-0000";

function bakeryFacts() {
  const services = quoteServices.map((s) => `- ${s.name}: $${s.unitPrice} per ${s.unitLabel} (estimate)`).join("\n");
  const menu = pickupMenu.map((m) => `- ${m.name}: $${m.price}`).join("\n");
  return `Sunrise Bakery — a family bakery in Astoria, Queens.
Services and estimate prices:
${services}
Pickup menu:
${menu}
Hours: Monday to Friday, 8 AM to 9 PM. Closed Saturday and Sunday.
Address: Astoria, Queens, NY
Phone: ${PHONE}
Customers can also place a pickup order on the website's "Order for pickup" page.`;
}

const instructions = `You are the friendly chat helper for Sunrise Bakery. Answer ONLY using these facts:
${bakeryFacts()}

Rules:
- Keep answers short (1-3 sentences), warm and friendly.
- If the answer is not in the facts, reply exactly: "Please call us at ${PHONE}."
- If the customer wants to book or order something, ask for their name and phone number (and what/when if not given). Once you have both name and phone, call save_request, then confirm we'll call or text them soon.
- Never invent prices, products, or hours.`;

function publicDb() {
  const url = process.env["SUPABASE_URL"]!;
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"]!;
  return createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: {
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
        h.set("apikey", key);
        return fetch(input, { ...init, headers: h });
      },
    },
  });
}

export async function handleChat(request: Request) {
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) return new Response("Chat is not set up yet.", { status: 500 });
  const body = (await request.json()) as { messages?: UIMessage[] };
  const messages = (body.messages ?? []).slice(-30);

  const provider = createOpenAI({
    baseURL: "https://ai.gateway.lovable.dev/v1",
    apiKey,
    headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
  });

  const result = streamText({
    model: provider.responses("openai/gpt-6-astra"),
    instructions,
    messages: await convertToModelMessages(messages),
    abortSignal: request.signal,
    stopWhen: stepCountIs(50),
    tools: {
      save_request: tool({
        description: "Save a customer's booking or order request once you have their name and phone number.",
        inputSchema: z.object({
          name: z.string().describe("Customer name"),
          phone: z.string().describe("Customer phone number"),
          request_type: z.enum(["booking", "order"]),
          details: z.string().describe("What they want and when, e.g. 'booking for Saturday'"),
        }),
        execute: async ({ name, phone, request_type, details }) => {
          const n = name.trim().slice(0, 120);
          const p = phone.trim().slice(0, 30);
          if (!n || p.length < 3) return { saved: false, reason: "Need a name and a phone number." };
          const { error } = await publicDb().from("chat_requests").insert({
            customer_name: n, phone: p, request_type, details: details.trim().slice(0, 1000),
          });
          if (error) { console.error("chat request insert failed", error.message); return { saved: false, reason: "Could not save." }; }
          return { saved: true };
        },
      }),
    },
    providerOptions: {
      openai: {
        store: false,
        forceReasoning: true,
        reasoningEffort: "low",
        include: ["reasoning.encrypted_content"],
      },
    },
  });
  return result.toUIMessageStreamResponse();
}
