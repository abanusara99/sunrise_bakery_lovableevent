import { z } from "zod";

export const feedbackSchema = z.object({
  name: z.string().trim().max(120),
  rating: z.number().int().min(1).max(5),
  message: z.string().trim().min(1, "Please add your feedback.").max(2000),
});
export type FeedbackInput = z.infer<typeof feedbackSchema>;