export const pickupMenu = [
  { id: "one-piece", name: "One piece", price: 2 },
  { id: "wedding", name: "Wedding cake", price: 80 },
  { id: "party-huge-cake", name: "Party huge cake", price: 110 },
] as const;

export type PickupQuantities = Record<string, number>;

export function orderLines(quantities: PickupQuantities) {
  return pickupMenu
    .map((item) => ({ ...item, quantity: Math.max(0, Math.floor(quantities[item.id] ?? 0)) }))
    .filter((line) => line.quantity > 0)
    .map((line) => ({ ...line, lineTotal: line.price * line.quantity }));
}

export function orderTotal(quantities: PickupQuantities) {
  return orderLines(quantities).reduce((sum, line) => sum + line.lineTotal, 0);
}
