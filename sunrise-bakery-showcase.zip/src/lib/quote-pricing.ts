/**
 * Shared quote pricing. Browser-safe: no secrets, no server APIs.
 *
 * NOTE: the unit prices below are PLACEHOLDERS until Sunrise Bakery confirms
 * real numbers. The same table is read by the server function, so the price
 * the customer sees is always the price that gets saved.
 */
export type QuoteService = {
  id: string;
  name: string;
  unitLabel: string;
  quantityLabel: string;
  placeholder: string;
  unitPrice: number;
};

export const quoteServices: QuoteService[] = [
  {
    id: "birthday_cakes",
    name: "Custom birthday cakes",
    unitLabel: "cake",
    quantityLabel: "How many cakes?",
    placeholder: "e.g. 2",
    unitPrice: 65,
  },
  {
    id: "bread_pastries",
    name: "Fresh bread and pastries",
    unitLabel: "order",
    quantityLabel: "How many loaves or pastries?",
    placeholder: "e.g. 12",
    unitPrice: 8,
  },
  {
    id: "catering",
    name: "Catering trays for events",
    unitLabel: "tray",
    quantityLabel: "How many catering trays?",
    placeholder: "e.g. 4",
    unitPrice: 45,
  },
];

export const defaultQuoteServiceId: string = quoteServices[0]?.id ?? "birthday_cakes";

export const quoteServiceById = (id: string) => quoteServices.find((service) => service.id === id);

export const estimateQuote = (serviceId: string, quantity: number) => {
  const service = quoteServiceById(serviceId);
  if (!service || !Number.isInteger(quantity) || quantity < 1 || quantity > 999) return null;
  return { service, quantity, unitPrice: service.unitPrice, total: service.unitPrice * quantity };
};

export const money = (amount: number) =>
  amount.toLocaleString("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  });
