import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";

import { orderLines } from "./pickup-menu";

const orderSchema = z.object({
  quantities: z.record(z.string().max(60), z.number().int().min(0).max(999)),
  name: z.string().trim().min(1, "Please tell us your name.").max(120),
  phone: z.string().trim().min(3, "Please add a phone number.").max(30),
  pickupTime: z.string().trim().min(1, "Please choose a pickup time.").max(40),
});

export type PickupOrderInput = z.infer<typeof orderSchema>;

export const submitPickupOrder = createServerFn({ method: "POST" })
  .inputValidator((input: PickupOrderInput) => orderSchema.parse(input))
  .handler(async ({ data }) => {
    const lines = orderLines(data.quantities);
    if (lines.length === 0) throw new Error("Please add at least one item.");
    const total = lines.reduce((s, l) => s + l.lineTotal, 0);
    const pickup = new Date(data.pickupTime);
    if (Number.isNaN(pickup.getTime())) throw new Error("Please choose a valid pickup time.");

    const url = process.env["SUPABASE_URL"];
    const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
    if (!url || !key) throw new Error("The bakery database is not ready yet.");
    const supabasePublic = createClient(url, key, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: {
        fetch: (input, init) => {
          const headers = new Headers(init?.headers);
          if (key.startsWith("sb_") && headers.get("Authorization") === `Bearer ${key}`) headers.delete("Authorization");
          headers.set("apikey", key);
          return fetch(input, { ...init, headers });
        },
      },
    });

    const { error } = await supabasePublic.from("pickup_orders").insert({
      customer_name: data.name,
      phone: data.phone,
      pickup_time: pickup.toISOString(),
      items: lines.map((l) => ({ id: l.id, name: l.name, price: l.price, quantity: l.quantity, line_total: l.lineTotal })),
      total,
    });
    if (error) {
      console.error("order insert failed", error.message);
      throw new Error("We couldn't save your order just now. Please give us a call instead.");
    }
    return { ok: true as const, total };
  });
