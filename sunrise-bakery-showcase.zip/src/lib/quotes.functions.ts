import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";

import { quoteServiceById } from "./quote-pricing";

const quoteInputSchema = z.object({
  serviceId: z.string().trim().min(1).max(60),
  quantity: z.number().int().min(1).max(999),
  name: z.string().trim().min(1, "Please tell us your name.").max(120),
  phone: z.string().trim().min(3, "Please add a phone number.").max(30),
});

export type QuoteInput = z.infer<typeof quoteInputSchema>;

export const submitQuote = createServerFn({ method: "POST" })
  .inputValidator((input: QuoteInput) => quoteInputSchema.parse(input))
  .handler(async ({ data }) => {
    const service = quoteServiceById(data.serviceId);
    if (!service) throw new Error("Please choose one of our services.");

    // The saved price is always recalculated here, never trusted from the browser.
    const total = service.unitPrice * data.quantity;

    const url = process.env["SUPABASE_URL"];
    const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
    if (!url || !key) throw new Error("The bakery database is not ready yet.");

    const supabasePublic = createClient(url, key, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: {
        fetch: (input, init) => {
          const headers = new Headers(init?.headers);
          if (key.startsWith("sb_") && headers.get("Authorization") === `Bearer ${key}`) {
            headers.delete("Authorization");
          }
          headers.set("apikey", key);
          return fetch(input, { ...init, headers });
        },
      },
    });

    const { error } = await supabasePublic.from("quote_requests").insert({
      service_id: service.id,
      service_name: service.name,
      quantity: data.quantity,
      unit_price: service.unitPrice,
      estimated_total: total,
      customer_name: data.name,
      phone: data.phone,
    });

    if (error) {
      console.error("quote insert failed", error.message);
      throw new Error("We couldn't save your quote just now. Please give us a call instead.");
    }

    return { ok: true as const, total, serviceName: service.name, quantity: data.quantity };
  });
