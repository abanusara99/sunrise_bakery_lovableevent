import { useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowUpRight, Menu, Sun, X } from "lucide-react";
import { Button } from "@/components/ui/button";

export function BakeryHeader() {
  const [open, setOpen] = useState(false);
  const toggle = useRef<HTMLButtonElement>(null);
  const close = () => setOpen(false);
  return (
    <header className="site-header" onKeyDown={(event) => {
      if (event.key === "Escape" && open) { close(); toggle.current?.focus(); }
    }}>
      <div className="header-inner">
        <Link to="/" className="wordmark" aria-label="Sunrise Bakery home" onClick={close}><Sun aria-hidden="true" /><span>Sunrise<span className="wordmark-small">BAKERY</span></span></Link>
        <Button ref={toggle} className="menu-toggle" variant="ghost" size="icon" aria-label={open ? "Close menu" : "Open menu"} aria-expanded={open} aria-controls="bakery-navigation" onClick={() => setOpen(!open)} title={open ? "Close menu" : "Open menu"}>
          {open ? <X aria-hidden="true" /> : <Menu className="vertical-menu-icon" aria-hidden="true" />}
        </Button>
        <nav id="bakery-navigation" className={open ? "bakery-navigation is-open" : "bakery-navigation"} aria-label="Main navigation" onClick={close}>
          <Link to="/" hash="services">Our baking</Link>
          <Link to="/" hash="photos">Photos</Link>
          <Link to="/" hash="quote">Quick quote</Link>
          <Link to="/order">Order for pickup</Link>
          <Link to="/" hash="feedback">Feedback</Link>
          <Link to="/" hash="visit">Hours & location</Link>
        </nav>
        <Button asChild className="header-visit"><Link to="/" hash="visit">Come say hello <ArrowUpRight /></Link></Button>
      </div>
    </header>
  );
}