import { useState } from "react";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport } from "ai";
import ReactMarkdown from "react-markdown";
import { HelpCircle, Send, Sun, X } from "lucide-react";

export function ChatHelper() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const { messages, sendMessage, status, error } = useChat({ transport: new DefaultChatTransport({ api: "/api/chat" }) });
  const busy = status === "submitted" || status === "streaming";

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const text = input.trim();
    if (!text || busy) return;
    sendMessage({ text });
    setInput("");
  }

  if (!open) {
    return (
      <button className="chat-launcher" onClick={() => setOpen(true)} aria-label="Open chat helper" title="Ask a question">
        <HelpCircle size={26} />
      </button>
    );
  }

  return (
    <div className="chat-panel" role="dialog" aria-label="Sunrise Bakery chat helper">
      <div className="chat-head">
        <span className="chat-title"><Sun size={18} /> Sunrise helper</span>
        <button onClick={() => setOpen(false)} aria-label="Close chat"><X size={18} /></button>
      </div>
      <div className="chat-body" data-testid="chat-body">
        <div className="chat-msg chat-bot">Hi! Ask me about our cakes, prices, hours, or booking. 🍞</div>
        {messages.map((m) => {
          const text = m.parts.map((p) => (p.type === "text" ? p.text : "")).join("");
          if (!text) return null;
          return (
            <div key={m.id} className={`chat-msg ${m.role === "user" ? "chat-user" : "chat-bot"}`}>
              {m.role === "user" ? text : <ReactMarkdown>{text}</ReactMarkdown>}
            </div>
          );
        })}
        {status === "submitted" && <div className="chat-msg chat-bot chat-typing">…</div>}
        {error && <div className="chat-msg chat-bot">Sorry, I couldn’t answer just now. Please call us at +1 000-000-0000.</div>}
      </div>
      <form className="chat-form" onSubmit={submit}>
        <input aria-label="Your message" placeholder="Type a question…" value={input} onChange={(e) => setInput(e.target.value)} />
        <button type="submit" aria-label="Send" disabled={busy}><Send size={17} /></button>
      </form>
    </div>
  );
}
