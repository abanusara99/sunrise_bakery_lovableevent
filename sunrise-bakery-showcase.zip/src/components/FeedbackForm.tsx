import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Check, Send, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { submitFeedback } from "@/lib/feedback.functions";
import { feedbackSchema } from "@/lib/feedback-schema";

export function FeedbackForm() {
  const send = useServerFn(submitFeedback);
  const [name, setName] = useState("");
  const [rating, setRating] = useState(0);
  const [message, setMessage] = useState("");
  const [status, setStatus] = useState<"idle" | "saving" | "sent">("idle");
  const [error, setError] = useState("");
  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    if (status === "saving") return;
    const parsed = feedbackSchema.safeParse({ name, rating, message });
    if (!parsed.success) { setError(rating === 0 ? "Please choose a star rating." : "Please add your feedback (up to 2,000 characters)."); return; }
    setError(""); setStatus("saving");
    try { await send({ data: parsed.data }); setStatus("sent"); }
    catch (err) { setStatus("idle"); setError(err instanceof Error ? err.message : "Please try again."); }
  }
  return (
    <section className="feedback-section" id="feedback">
      <div className="feedback-intro"><p className="eyebrow">FROM OUR NEIGHBORS, WITH LOVE</p><h2>How was your visit?</h2><p>We’d love to hear what you think.</p></div>
      {status === "sent" ? <div className="feedback-success" role="status"><Check aria-hidden="true" /><h3>Thank you for your feedback!</h3><p>We’re glad you took a moment to share.</p><Button variant="outline" onClick={() => { setName(""); setRating(0); setMessage(""); setStatus("idle"); }}>Share more feedback</Button></div> :
        <form className="feedback-form" onSubmit={onSubmit} aria-label="Customer feedback">
          <fieldset className="feedback-rating"><legend>Your rating</legend><div className="feedback-stars" role="radiogroup" aria-label="Your rating">{[1, 2, 3, 4, 5].map((value) => <Button key={value} variant="ghost" size="icon" type="button" role="radio" aria-checked={rating === value} aria-label={`${value} ${value === 1 ? "star" : "stars"}`} title={`${value} ${value === 1 ? "star" : "stars"}`} className={value <= rating ? "feedback-star selected" : "feedback-star"} onClick={() => { setRating(value); setError(""); }} onKeyDown={(event) => { if (["ArrowRight", "ArrowDown", "ArrowLeft", "ArrowUp"].includes(event.key)) { event.preventDefault(); const next = Math.max(1, Math.min(5, value + (["ArrowRight", "ArrowDown"].includes(event.key) ? 1 : -1))); setRating(next); event.currentTarget.parentElement?.querySelectorAll<HTMLButtonElement>("button")[next - 1]?.focus(); } }}><Star aria-hidden="true" /></Button>)}</div></fieldset>
          <label className="quote-field"><span>Your name (optional)</span><input value={name} onChange={(event) => setName(event.target.value)} maxLength={120} autoComplete="name" /></label>
          <label className="quote-field"><span>Your feedback</span><textarea value={message} onChange={(event) => setMessage(event.target.value)} required maxLength={2000} rows={5} /></label>
          <Button type="submit" size="lg" disabled={status === "saving"}>{status === "saving" ? "Sending…" : "Send feedback"}<Send aria-hidden="true" /></Button>
          {error && <p className="quote-note quote-note-bad" role="alert">{error}</p>}
        </form>}
    </section>
  );
}