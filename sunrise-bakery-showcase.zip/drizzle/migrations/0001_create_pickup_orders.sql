CREATE TABLE public.pickup_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL CHECK (char_length(customer_name) BETWEEN 1 AND 120),
  phone text NOT NULL CHECK (char_length(phone) BETWEEN 3 AND 30),
  pickup_time timestamptz NOT NULL,
  items jsonb NOT NULL,
  total numeric(10,2) NOT NULL CHECK (total > 0),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT INSERT ON public.pickup_orders TO anon, authenticated;
GRANT ALL ON public.pickup_orders TO service_role;
ALTER TABLE public.pickup_orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can place a pickup order" ON public.pickup_orders FOR INSERT TO anon, authenticated WITH CHECK (true);