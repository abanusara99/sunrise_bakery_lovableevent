CREATE TABLE public.quote_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  service_id TEXT NOT NULL,
  service_name TEXT NOT NULL,
  quantity INTEGER NOT NULL CHECK (quantity BETWEEN 1 AND 999),
  unit_price NUMERIC(10,2) NOT NULL CHECK (unit_price >= 0),
  estimated_total NUMERIC(10,2) NOT NULL CHECK (estimated_total >= 0),
  customer_name TEXT NOT NULL CHECK (char_length(customer_name) BETWEEN 1 AND 120),
  phone TEXT NOT NULL CHECK (char_length(phone) BETWEEN 3 AND 30),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT INSERT ON public.quote_requests TO anon;
GRANT SELECT ON public.quote_requests TO authenticated;
GRANT ALL ON public.quote_requests TO service_role;

ALTER TABLE public.quote_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Visitors can send a quote request"
ON public.quote_requests
FOR INSERT
TO anon, authenticated
WITH CHECK (
  quantity BETWEEN 1 AND 999
  AND estimated_total = unit_price * quantity
  AND char_length(trim(customer_name)) > 0
  AND char_length(trim(phone)) > 0
);