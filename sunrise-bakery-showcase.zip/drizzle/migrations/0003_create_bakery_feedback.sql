CREATE TABLE public.bakery_feedback (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 customer_name text NOT NULL DEFAULT '' CHECK (char_length(customer_name) <= 120),
 rating integer NOT NULL CHECK (rating BETWEEN 1 AND 5),
 message text NOT NULL CHECK (char_length(btrim(message)) BETWEEN 1 AND 2000),
 created_at timestamptz NOT NULL DEFAULT now()
);
GRANT INSERT ON public.bakery_feedback TO anon, authenticated;
GRANT ALL ON public.bakery_feedback TO service_role;
ALTER TABLE public.bakery_feedback ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Visitors can submit feedback" ON public.bakery_feedback FOR INSERT TO anon, authenticated WITH CHECK (rating BETWEEN 1 AND 5 AND char_length(customer_name) <= 120 AND char_length(btrim(message)) BETWEEN 1 AND 2000);